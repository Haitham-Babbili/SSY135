clear;
close all
%Time and frequency-varing Rician fading channels
%simulation parameters
M = 300; N = 64; %Time samples; frequency samples
L = [1 2 3];     %Number of taps
fDTs = [.1 .005];%relative doppler shift
kc = [0 1 10];   %power of LOS
Ts = .01;        %sample interval =>f_D = fDTs
N_filter = 1000;          %2*N+1 is the length of the filter(filter method)
N_s = 100000;
method = 1;      %0 = filter method; 1 = spectrum method
%for testing
% c = rician_gen(Ts,fDTs(2)/Ts,kc,3,400,10000,1);
% C = fft(c,N);
% plot_rician(C(1:N,1:M),M,N)
%
for i = 1:3
    %kc loop
    for j = 1:2
        %fdTs loop
        for k = 1:3
            %L loop
            taps = L(k);
            %return c(tau,t) (time domain)
            c = rician_gen(Ts,fDTs(j)/Ts,kc(i),taps,N_filter,N_s,method);
            %calculate fft in respect to tau
            C = fft(c,N);
            figure
            fig = plot_rician(C(1:N,1:M),M,N);
            title(sprintf('k = %d, taps = %d, fDTs = %.3f',kc(i),taps,fDTs(j)))
            saveas(fig,sprintf('taskB_(%d,%d,%.3f)_(k,taps,fDTs).png',kc(i),taps,fDTs(j)),'png')
        end
    end
end