function fig = plot_rician( C,M,N )
%PLOT_RICIAN Summary of this function goes here
%   Detailed explanation goes here
%   from project pm
colormap('jet')
% subplot(1, 2, 1)
% mesh(1:M, 0:N-1, abs(C));
% ylabel('frequency [1/(NTs)]')
% xlabel('time [Ts]')
% zlabel('|C[k, n]|')
set(gca, 'Ylim', [0 N-1], 'Xlim', [1 M])
% subplot(1, 2, 2)
fig = surf(1:M, 0:N-1, abs(C), 'MeshStyle', 'row');
ylabel('frequency [1/(NTs)]')
xlabel('time [Ts]')
set(gca, 'Ylim', [0 N-1], 'Xlim', [0 M-1])
view(2)
end