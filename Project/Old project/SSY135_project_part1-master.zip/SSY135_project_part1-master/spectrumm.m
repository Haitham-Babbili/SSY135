function c = spectrumm(N_s, T_s, f_D, k_c)
%% FILTERM Simulate channel gain using the spectrum method.
% N_s: Number of gain coefficients to generate.
% T_s: Sample time.
% f_D: Doppler spectrum.
% k_c: Dominant ray coefficient.

% Compute the sampling frequency
f_s = 1 / T_s;

if f_s < 2*f_D
    error(['The sampling frequency f_s must be at least 2*f_D to ' ...
           'avoid aliasing.'])
end

% Define S_c_prime and the the filter G in the frequency domain.
S_c_prime = @(f, f_D) 1 ./ (pi * f_D * ...
                            sqrt(1 - (f / f_D).^2)) .* (abs(f) < f_D);
G = @(f, f_D) sqrt(S_c_prime(f, f_D));

% Compute samples from G_tilde = G(f) + G(f - f_s)
G_0_f_D = G(0:(f_s/N_s):(f_D - f_s/N_s), f_D);
G_tilde = [G_0_f_D zeros(1, ceil((f_s - 2*f_D) / (f_s/N_s))) fliplr(G_0_f_D)];

% Validate G_tilde
if sum(isnan(G_tilde)) ~= 0
    error('G_tilde has a NaN value.')
end

if sum(isinf(G_tilde)) ~= 0
    error('G_tilde has an inf value.')
end

% Compute a scaling factor K such that c will have unit variance.
K = sqrt(N_s * (N_s - 1)) * sqrt(1 / sum(G_tilde.^2));

% Generate samples of discrete-time, independent, zero-mean
% Gaussian complex noise.
X = K * (randn(1, N_s) + 1i * randn(1, N_s)) * sqrt(1/2);

% Compute c_prime as the N_s-point IDFT of the samples
c_prime = ifft(G_tilde .* X, N_s);

% Compute c
c = c_prime + k_c;
