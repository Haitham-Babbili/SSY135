function c = filterm(N_s, T_s, f_D, k_c, N)
%% FILTERM Simulate channel gain using the filter method.
% N_s: Number of gain coefficients to generate.
% T_s: Sample time.
% f_D: Doppler spectrum.
% k_c: Dominant ray coefficient.
% N:  The filter is sampled 2*N + 1 times.

if N_s < 2*N + 1
    error('N_s must be larger than 2N + 1.')
end

if N_s < 100*N
    warning('The N_s >> 2N + 1 assumption may be violated.')
end

% Compute the sampling frequency
f_s = 1 / T_s;

if f_s < 2*f_D
    error(['The sampling frequency f_s must be at least 2*f_D to ' ...
           'avoid aliasing.'])
end

% Define the filter g(t) for t > 0
g = @(t) besselj(1/4, 2*pi * f_D * abs(t)) ./ (abs(t) .^ (1/4));

% Genrate samples from the filter g(t) for times -N*T_s up to
% N*T_s. g(t) is shifted implicitly by considering the first sample
% to have been taken at t=0 for the rest of the simulation.
g_0 = (pi * f_D) ^ (1/4) / gamma(5/4); % Filter output at t=0
g_1_N = g((1:N)*T_s); % Filter output for t=1*T_s, ..., t=N*T_s
g_hat = [fliplr(g_1_N) g_0 g_1_N];

% Pass the samples of g(t) through a windowing function.
g_hat = g_hat .* rectwin(length(g_hat))';
%g_hat = g_hat .* hamming(length(g_hat))';

% Verify that the sample vector has correct length.
if length(g_hat) ~= 2*N + 1
    error('Length of g_hat was not N + 1.')
end

% Normalize the samples of g(t) to have unit power.
K = 1 / sqrt(sum(g_hat .^ 2));
g_hat = K * g_hat;

% Generate samples of discrete-time, white complex noise.
x = (randn(1, N_s) + 1i * randn(1, N_s)) * sqrt(1/2);

% Compute c_prime by convolving x with g and discarding the samples
% that are due to filter transients.
c_prime = conv(x, g_hat, 'same');

% Compute c
c = c_prime + k_c;
