function [ c ] = rician_gen(Ts,f_D,kc,taps,N_filter,N_s,method )
%RICIAN_GEN Generates a realization of Rician fading channel
%   Ts: sample interval
%   f_D: Doppler frequency
%   kc: LOS
%   taps: number of taps
%   N_filter: filter length (filterm.m)
%   N_s: number of samples (t axis)
%   method: 0 for filterm.m, 1 for spectrumm.m
c = zeros(taps *2 ,N_s);
switch method
    case 0
        for tau = 1:2:taps*2
            temp = filterm(N_s, Ts, f_D, kc,N_filter);
            c(tau,:) = temp;
        end    
    case 1
        for tau = 1:2:taps*2
            temp = spectrumm(N_s, Ts, f_D, kc);
            c(tau,:) = temp;
        end        
    otherwise
        error('invalid method')
end

end

