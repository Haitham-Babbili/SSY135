clear; clc;
close all;

% Set system parameters
f_D = 56;
N_s = 100000;
k_c = 0;
N = 1000;

% Set T_s according to PM.
T_s = 1e-4;
f_s = 1 / T_s;

% Generate sample input s(t). Output is calculated according to
% r(t) = c(t)s(t), c(t) = c'(t) + k_c.
s = sin((1:N_s)/200) + 1i * sin((1:N_s)/200);

% Simulate the channel gain
c_spectrum = spectrumm(N_s, T_s, f_D, k_c);
c_filter = filterm(N_s, T_s, f_D, k_c, N);

% Compute the output r
r_spectrum = c_spectrum .* s;
r_filter = c_filter .* s;

% Estimate the power spectral density (PSD) of the gain coefficients.
[c_spectrum_psd, f_spectrum] = pwelch(c_spectrum, [], [], [], f_s);
[c_filter_psd, f_filter] = pwelch(c_filter, [], [], [], f_s);

% Define S_c_prime.
S_c_prime = @(f, f_D) 1 ./ (pi * f_D * ...
                            sqrt(1 - (f / f_D).^2)) .* (abs(f) <= f_D);

% Sample S_c_prime from 0 to f_D and convert to dB.
theory_psd = S_c_prime(linspace(0, f_D), f_D);
theory_psd = 10*log10(theory_psd);

% Plot the PSD and compare to theory.
figure; hold on;
plot(f_spectrum, 10*log10(c_spectrum_psd), 'r')
plot(f_filter, 10*log10(c_filter_psd), 'b')
plot(linspace(0, f_D, length(theory_psd)), ...
     theory_psd, 'k', 'LineWidth', 3)
plot(linspace(f_s-f_D, f_s, length(theory_psd)), ...
     fliplr(theory_psd), 'k', 'LineWidth', 3)
hold off; grid on;
legend('Spectrum method', 'Filter method', 'Theory')
title('Power Spectral Density Estimate')
xlabel('Frequency (Hz)'); ylabel('Power/Frequency (dB/Hz)');

%% estimate pdf and cdf of abs(c)
% define the pdf and cdf of Rician fading
rician_dist = makedist('Rician','s',k_c,'sigma',1/sqrt(2));
figure
subplot(2,1,1),
%plot cdf
hold on,
[p,xi] = ksdensity(abs(c_filter),'Support','positive','function','cdf');
plot(xi,p,'LineStyle','-.')
[p,xi] = ksdensity(abs(c_spectrum),'Support','positive','function','cdf');
plot(xi,p,'LineStyle','--')
plot(linspace(0,max(xi),1000), rician_dist.cdf(linspace(0,max(xi),1000)),'LineWidth',1.5);
title(sprintf('CDF (kc = %d)',k_c))
legend('filter','spectrum','theory')
%plot pdf
subplot(2,1,2),
hold on
[p,xi] = ksdensity(abs(c_filter),'Support','positive','function','pdf');
plot(xi,p,'LineStyle','-.')
[p,xi] = ksdensity(abs(c_spectrum),'Support','positive','function','pdf');
plot(xi,p','LineStyle','--')
plot(linspace(0,max(xi),1000), rician_dist.pdf(linspace(0,max(xi),1000)),'LineWidth',1.5)
title(sprintf('PDF (kc = %d)',k_c))
legend('filter','spectrum','theory')
%% compare the autocorrelation of c
A_c = @(delta_t,kc,f_D) besselj(0,2 * pi * f_D * delta_t) + kc^2; %theoretical autocorrelation
c_filter_autocorr = real(xcorr(c_filter,N,'unbiased'));
c_spectrum_autocorr = real(xcorr(c_spectrum,N,'unbiased'));
temp = (-N:N)*T_s;
figure
plot(temp ,[c_filter_autocorr; c_spectrum_autocorr; A_c(temp,k_c,f_D)])
legend('filter method','spectrum method','theory')
xlabel('t/s')
ylabel('autocorrelation')
%% Plot the envelope of the input, output and channel gain.
figure;
subplot(2, 2, 1)
hold on;
plot(abs(r_spectrum), 'r')
plot(abs(s), 'b', 'LineWidth', 2)
title('Input/Output: Spectrum Method')
legend('Output', 'Input')
grid on
hold off

subplot(2, 2, 2)
plot(abs(c_spectrum), 'k')
title('Channel Gain: Spectrum Method')
grid on

subplot(2, 2, 3)
hold on;
plot(abs(r_filter), 'r')
plot(abs(s), 'b', 'LineWidth', 2)
title('Input/Output: FIlter Method')
legend('Output', 'Input')
grid on
hold off

subplot(2, 2, 4)
plot(abs(c_filter), 'k')
title('Channel Gain: Filter Method')
grid on

return
